function plotlist = newplotlist()

% function plotlist = newplotlist()
% 
% maak een lege list van grafieken
% 
% zie ook : plotlist, addplotlist, doplotlist, plot

plotlist = {};


